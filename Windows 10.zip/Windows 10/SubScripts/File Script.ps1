﻿ 
 New-Item $PSScriptRoot\UserFiles.txt
 
 Get-ChildItem -Path C:\Users -Include *AIF*,*M3U*,*TXT*,*M4A*,*MID*,*MP3*,*MPA*,*RA*,*WAV*,*WMA*,*3G2*,*3GP*,*ASF*,*ASX*,*AVI*,*FLV*,*M4V*,*MOV*,*MP4*,*MPG*,*RM*,*SRT*,*SWF*,*VOB*,*WMV*,*BMP*,*GIF*,*JPG*,*PNG*,*PSD*,*TIF*,*YUV*,*GAM*,*SAV*,*TORRENT*,*WEBM*,*FLV*,*OG* -Recurse -ErrorAction SilentlyContinue | Out-File -FilePath $PSScriptRoot\UserFiles.txt
