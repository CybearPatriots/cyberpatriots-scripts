﻿
$Extension = ("AIF","M3U","TXT","M4A","MID","MP3","MPA","RA","WAV","WMA","3G2","3GP","ASF","ASX","AVI","FLV","M4V","MOV","MP4","MPG","RM","SRT","SWF","VOB","WMV","BMP","GIF","JPG","PNG","PSD","TIF","YUV","GAM","SAV","TORRENT","WEBM","FLV","OG")
foreach ($Extension in $Extensions) {
$Files = Get-ChildItem -Path C:\Users -Recurse -Filter *$Extension 
$Files | Out-File $PSScriptRoot\Files.txt
}