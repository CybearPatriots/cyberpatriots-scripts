﻿# Script Directory
$PSScriptRoot

#Important Variables - 
$UserPassword = CyberPatriot!

echo "Starting..."

# Password and Default Account Settings
net accounts /minpwlen:10
net accounts /maxpwage:30
net accounts /minpwage:3
net user Administrator /active:no
net user Guest /active:no
net user DefaultAccount /active:no
net accounts /UniquePw:5

echo  "(1/x)"

#Export netstat
netstat -aonb | Out-File $PSScriptRoot\Output\netstat.txt

echo "(2/x)"

#Set All User Passwords
$Users = get-wmiobject -class win32_useraccount -filter "LocalAccount='true'"
foreach ($Username in $Users) {
net user $Username.Name $UserPassword /passwordreq:yes /logonpasswordchg:yes /PasswordChg:No}
wmic UserAccount set PasswordExpires=True
wmic UserAccount set Lockout=False


echo "(3/x)"

#Remove Programs
echo "Opening Uninstall Wizzard..."
control appwiz.cpl

echo "(4/x)"

#Enable Firewall
netsh advfirewall set allprofiles state on 
netsh advfirewall firewall set rule name="Remote Assistance (DCOM-In)" new enable=no 
netsh advfirewall firewall set rule name="Remote Assistance (PNRP-In)" new enable=no 
netsh advfirewall firewall set rule name="Remote Assistance (RA Server TCP-In)" new enable=no 
netsh advfirewall firewall set rule name="Remote Assistance (SSDP TCP-In)" new enable=no 
netsh advfirewall firewall set rule name="Remote Assistance (SSDP UDP-In)" new enable=no 
netsh advfirewall firewall set rule name="Remote Assistance (TCP-In)" new enable=no 
netsh advfirewall firewall set rule name="Telnet Server" new enable=no 
netsh advfirewall firewall set rule name="netcat" new enable=no
 
echo "(5/x)"

#Enable Structured Exception Handling Overwrite Protection
Set-ItemProperty -path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" -name DisableExceptionChainValidation -value 0

echo "(6/x)"

#Enable Structured Exception Handling Overwrite Protection
Set-ItemProperty -path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -name LocalAccountTokenFilterPolicy -value 0

echo "(7/x)"

#Diable AutoPlay

New-Item -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies" -Name Explorer
New-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" -name NoDriveTypeAutoRun -value 0xff -ErrorAction Continue 
Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" -name NoDriveTypeAutoRun -value 0xff 
New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -name DisableAutoplay -value 1 -ErrorAction Continue 
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers" -name DisableAutoplay -value 1 

echo "(8/x)"

#Disable and Enable Key Services
#Disable
Stop-Service tapisrv -Force -EA SilentlyContinue
Set-Service tapisrv -StartupType Disabled -EA SilentlyContinue
Stop-Service mcx2svc -Force -EA SilentlyContinue
Set-Service mcx2svc -StartupType Disabled -EA SilentlyContinue
Stop-Service remoteregistry -Force -EA SilentlyContinue
Set-Service remoteregistry -StartupType Disabled -EA SilentlyContinue
Stop-Service seclogon -Force -EA SilentlyContinue
Set-Service seclogon -StartupType Disabled -EA SilentlyContinue
Stop-Service telnet -Force -EA SilentlyContinue
Set-Service telnet -StartupType Disabled -EA SilentlyContinue
Stop-Service tlntsvr -Force -EA SilentlyContinue
Set-Service tlntsvr -StartupType Disabled -EA SilentlyContinue
Stop-Service p2pimsvc -Force -EA SilentlyContinue
Set-Service p2pimsvc -StartupType Disabled -EA SilentlyContinue
Stop-Service simptcp -Force -EA SilentlyContinue
Set-Service simptcp -StartupType Disabled -EA SilentlyContinue
Stop-Service fax -Force -EA SilentlyContinue
Set-Service fax -StartupType Disabled -EA SilentlyContinue
Stop-Service msftpsvc -Force -EA SilentlyContinue
Set-Service msftpsvc -StartupType Disabled -EA SilentlyContinue
Stop-Service cscservice -Force -EA SilentlyContinue
Set-Service cscservice -StartupType Disabled -EA SilentlyContinue
Stop-Service msftpsvc -Force -EA SilentlyContinue
Set-Service msftpsvc -StartupType Disabled -EA SilentlyContinue
Stop-Service webclient -Force -EA SilentlyContinue
Set-Service webclient -StartupType Disabled -EA SilentlyContinue
echo "Disable Done"

#Enable
Set-Service eventlog -StartupType Automatic -EA SilentlyContinue 
Start-Service eventlog -EA SilentlyContinue 
Set-Service mpssv -StartupType Automatic -EA SilentlyContinue 
Start-Service mpssv -EA SilentlyContinue 
Set-Service windefend -StartupType Automatic -EA SilentlyContinue 
Start-Service windefend -EA SilentlyContinue  
Set-Service sppsvc -StartupType Automatic -EA SilentlyContinue 
Start-Service sppsvc -EA SilentlyContinue 
Set-Service wuauserv -StartupType Automatic -EA SilentlyContinue 
Start-Service wuauserv -EA SilentlyContinue 
Set-Service wscsvc -StartupType Automatic -EA SilentlyContinue 
Start-Service wscsvc -EA SilentlyContinue 
echo "Enable Done"
echo "(9/x)"

#Audits
auditpol.exe /set /category:* /success:enable 
auditpol.exe /set /category:* /failure:enable
echo "(10/x)"

#File Checker
 New-Item $PSScriptRoot\Output\UserFiles.txt
 Get-ChildItem -Path C:\Users -Include *AIF*,*M3U*,*TXT*,*M4A*,*MID*,*MP3*,*MPA*,*RA*,*WAV*,*WMA*,*3G2*,*3GP*,*ASF*,*ASX*,*AVI*,*FLV*,*M4V*,*MOV*,*MP4*,*MPG*,*RM*,*SRT*,*SWF*,*VOB*,*WMV*,*BMP*,*GIF*,*JPG*,*PNG*,*PSD*,*TIF*,*YUV*,*GAM*,*SAV*,*TORRENT*,*WEBM*,*FLV*,*OG* -Recurse -ErrorAction SilentlyContinue | Out-File -FilePath $PSScriptRoot\Output\UserFiles.txt
 echo "(11/x)"

 #Registry Edits
 start-process "cmd.exe" "/c $PSScriptRoot\SubScripts\RegistryEdits.bat"
 echo "(12/x)"

 #RDP Toggle
 $RDP = read-host -prompt "Is RDP needed? (Y/N)"
if ($RDP -eq "Y") {
echo "Enabling RDP"
start-process "cmd.exe" "/c $PSScriptRoot\SubScripts\RDPE.bat"
}
if ($RDP -eq "N") {
echo "Disabling RDP"
start-process "cmd.exe" "/c $PSScriptRoot\SubScripts\RDPD.bat"
}
echo "(13/x)"

#Open Sysinternals Services 
Start-Process "$PSScriptRoot\Install And Imports\SysinternalsSuite\procexp.exe"
Start-Process "$PSScriptRoot\Install And Imports\SysinternalsSuite\Autoruns.exe"

echo "(14/x)"

#MalwareBytes Install Startup
Start-Process "$PSScriptRoot\Install And Imports\MWB.exe"

echo "(15/x)"