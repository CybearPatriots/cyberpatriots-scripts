﻿Start-Process "$PSScriptRoot\Install And Imports\SysinternalsSuite\procexp.exe"
Start-Process "$PSScriptRoot\Install And Imports\SysinternalsSuite\Autoruns.exe"
Start-Process "$PSScriptRoot\Install And Imports\MWB.exe"